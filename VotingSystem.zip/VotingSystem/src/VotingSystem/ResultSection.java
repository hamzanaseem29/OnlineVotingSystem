package VotingSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.SwingUtilities;

/**
 *
 * @author USER
 */
public class ResultSection extends javax.swing.JFrame {

    /**
     * Creates new form ResultSection
     */
    public ResultSection() {
        initComponents();
        countVotes();
    }

    public synchronized void countVotes() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinevotingsys", "root", "");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT vote, COUNT(vote) FROM votesection GROUP BY vote");

            int pti = 0, mqm = 0, pmln = 0, ji = 0, ppp = 0;
            while (rs.next()) {
                String party = rs.getString(1);
                int votes = rs.getInt(2);
                switch (party) {
                    case "PTI" -> {
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                ptiLabel.setText("PTI: " + votes);
                            }
                        });
                        Thread t1 = new Thread();
                        t1.start();
                    }

                    case "PPP" -> {
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                ppppLabel.setText("PPP: " + votes);
                            }
                        });
                        Thread t1 = new Thread();
                        t1.start();
                    }

                    case "PMLN" -> {
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                pmlnLabel.setText("PMLN: " + votes);
                            }
                        });
                        Thread t1 = new Thread();
                        t1.start();
                    }

                    case "JI" -> {
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                jiLabel.setText("JI: " + votes);
                            }
                        });
                        Thread t1 = new Thread();
                        t1.start();
                    }
                    case "MQM" -> {
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                mqmLabel.setText("MQM: " + votes);
                            }
                        });
                        Thread t1 = new Thread();
                        t1.start();
                    }
                }
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        backButton1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jiLabel = new javax.swing.JLabel();
        mqmLabel = new javax.swing.JLabel();
        pmlnLabel = new javax.swing.JLabel();
        ptiLabel = new javax.swing.JLabel();
        ppppLabel = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Results");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(102, 102, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Montserrat ExtraBold", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Results");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, -1, -1));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 84, 679, -1));

        backButton1.setBackground(new java.awt.Color(204, 204, 255));
        backButton1.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        backButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/left-arrow.png"))); // NOI18N
        backButton1.setText(" Back");
        backButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(backButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 20, -1, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jiLabel.setFont(new java.awt.Font("Montserrat ExtraBold", 0, 24)); // NOI18N
        jiLabel.setText("JI: 0");
        jPanel3.add(jiLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 160, -1, -1));

        mqmLabel.setFont(new java.awt.Font("Montserrat ExtraBold", 0, 24)); // NOI18N
        mqmLabel.setText("MQM: 0");
        jPanel3.add(mqmLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 330, -1, -1));

        pmlnLabel.setFont(new java.awt.Font("Montserrat ExtraBold", 0, 24)); // NOI18N
        pmlnLabel.setText("PML(N): 0");
        jPanel3.add(pmlnLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 160, -1, -1));

        ptiLabel.setFont(new java.awt.Font("Montserrat ExtraBold", 0, 24)); // NOI18N
        ptiLabel.setText("PTI: 0");
        jPanel3.add(ptiLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, -1, -1));

        ppppLabel.setFont(new java.awt.Font("Montserrat ExtraBold", 0, 24)); // NOI18N
        ppppLabel.setText("PPP: 0");
        jPanel3.add(ppppLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 330, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/PTI.png"))); // NOI18N
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 130, 150));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/JI.png"))); // NOI18N
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, -1, 130));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/PMLN.png"))); // NOI18N
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 20, 130, 130));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/MQM.png"))); // NOI18N
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, -1, 150));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/PPPP.png"))); // NOI18N
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 180, -1, 150));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButton1ActionPerformed

        MainSection obj = new MainSection();
        this.hide();
        obj.setVisible(true);
    }//GEN-LAST:event_backButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ResultSection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ResultSection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ResultSection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ResultSection.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new ResultSection().setVisible(true);
                } catch (Exception e) {
                    System.out.println("The Page is crash");
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel jiLabel;
    private javax.swing.JLabel mqmLabel;
    private javax.swing.JLabel pmlnLabel;
    private javax.swing.JLabel ppppLabel;
    private javax.swing.JLabel ptiLabel;
    // End of variables declaration//GEN-END:variables
}
