package VotingSystem;

import java.awt.event.KeyEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public final class VoteSection extends javax.swing.JFrame {

    ResultSection voteCounter = new ResultSection();

    public VoteSection() {
        initComponents();
        Connect();
        tableUpdate();
    }
    java.sql.Connection con;
    PreparedStatement pst;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        backButton = new javax.swing.JButton();
        PartiesButton2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtname = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtfname = new javax.swing.JLabel();
        txtdob = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtgender = new javax.swing.JLabel();
        txtvote = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Vote");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(102, 102, 255));

        jLabel1.setFont(new java.awt.Font("Montserrat ExtraBold", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Vote");

        backButton.setBackground(new java.awt.Color(204, 204, 255));
        backButton.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        backButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/left-arrow.png"))); // NOI18N
        backButton.setText(" Back");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        PartiesButton2.setBackground(new java.awt.Color(204, 204, 255));
        PartiesButton2.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        PartiesButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/pngwing.com (6) (Custom) (1).png"))); // NOI18N
        PartiesButton2.setText("Check Parites");
        PartiesButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PartiesButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(PartiesButton2)
                .addGap(201, 201, 201)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(backButton, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(backButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(PartiesButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        jLabel2.setText("NIC:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, -1, -1));

        jLabel3.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        jLabel3.setText("Name:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, -1, -1));

        jLabel4.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        jLabel4.setText("Father Name:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        jLabel5.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        jLabel5.setText("Gender:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, -1, -1));

        jLabel6.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        jLabel6.setText("Vote:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, -1, -1));

        txtnic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnicActionPerformed(evt);
            }
        });
        txtnic.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtnicKeyPressed(evt);
            }
        });
        jPanel2.add(txtnic, new org.netbeans.lib.awtextra.AbsoluteConstraints(163, 43, 185, 30));

        txtname.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        txtname.setForeground(new java.awt.Color(51, 51, 51));
        jPanel2.add(txtname, new org.netbeans.lib.awtextra.AbsoluteConstraints(163, 87, 190, -1));
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(277, 119, -1, -1));

        txtfname.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        txtfname.setForeground(new java.awt.Color(51, 51, 51));
        jPanel2.add(txtfname, new org.netbeans.lib.awtextra.AbsoluteConstraints(163, 119, 190, -1));

        txtdob.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        txtdob.setForeground(new java.awt.Color(51, 51, 51));
        jPanel2.add(txtdob, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 190, -1));

        jTable1.setFont(new java.awt.Font("Montserrat Light", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "NIC", "Name", "Father Name", "Gender", "DOB", "Vote"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 40, 460, 420));

        txtgender.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        txtgender.setForeground(new java.awt.Color(51, 51, 51));
        jPanel2.add(txtgender, new org.netbeans.lib.awtextra.AbsoluteConstraints(163, 151, 190, -1));

        txtvote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtvoteActionPerformed(evt);
            }
        });
        jPanel2.add(txtvote, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 212, 190, 30));

        jLabel7.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        jLabel7.setText("Date Of Birth:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, -1, -1));

        JiVoteButton.setBackground(new java.awt.Color(0, 102, 255));
        JiVoteButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        JiVoteButton.setForeground(new java.awt.Color(255, 255, 255));
        JiVoteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/JI (Custom).png"))); // NOI18N
        JiVoteButton.setText("  JI");
        JiVoteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JiVoteButtonActionPerformed(evt);
            }
        });
        jPanel2.add(JiVoteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, 170, 60));

        mqmVoteButton.setBackground(new java.awt.Color(255, 12, 12));
        mqmVoteButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        mqmVoteButton.setForeground(new java.awt.Color(255, 255, 255));
        mqmVoteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/MQM (Custom).png"))); // NOI18N
        mqmVoteButton.setText("  MQM");
        mqmVoteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mqmVoteButtonActionPerformed(evt);
            }
        });
        jPanel2.add(mqmVoteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 170, 60));

        ptiVoteButton.setBackground(new java.awt.Color(0, 102, 0));
        ptiVoteButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        ptiVoteButton.setForeground(new java.awt.Color(255, 255, 255));
        ptiVoteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/PTI (Custom).png"))); // NOI18N
        ptiVoteButton.setText("  PTI");
        ptiVoteButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ptiVoteButtonMouseEntered(evt);
            }
        });
        ptiVoteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ptiVoteButtonActionPerformed(evt);
            }
        });
        jPanel2.add(ptiVoteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 170, 60));

        pppVoteButton.setBackground(new java.awt.Color(153, 0, 0));
        pppVoteButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        pppVoteButton.setForeground(new java.awt.Color(255, 255, 255));
        pppVoteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/PPPP (Custom).png"))); // NOI18N
        pppVoteButton.setText("  PPP");
        pppVoteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pppVoteButtonActionPerformed(evt);
            }
        });
        jPanel2.add(pppVoteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 170, 60));

        pmlnVoteButton.setBackground(new java.awt.Color(50, 70, 1));
        pmlnVoteButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        pmlnVoteButton.setForeground(new java.awt.Color(255, 255, 255));
        pmlnVoteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/PMLN (Custom).png"))); // NOI18N
        pmlnVoteButton.setText("  PML(N)");
        pmlnVoteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pmlnVoteButtonActionPerformed(evt);
            }
        });
        jPanel2.add(pmlnVoteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 330, 170, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 877, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinevotingsys", "root", "");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(VoteSection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

//  Sychronized method tableUpdate it will update the table if the user click on votes... button
    public synchronized void tableUpdate() {
        int c;
        try {
            pst = con.prepareStatement("select * from  votesection");
            ResultSet rs = pst.executeQuery();

            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();

            DefaultTableModel d = (DefaultTableModel) jTable1.getModel();
            d.setRowCount(0);

            while (rs.next()) {
                Vector v2 = new Vector();

                for (int i = 1; i <= c; i++) {

                    v2.add(rs.getString("nic"));
                    v2.add(rs.getString("name"));
                    v2.add(rs.getString("fname"));
                    v2.add(rs.getString("gender"));
                    v2.add(rs.getString("dob"));
                    v2.add(rs.getString("vote"));

                }
                d.addRow(v2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(VoteSection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

//  Add/Check details
    public final void votingMethod() {
        String nic = txtnic.getText();
        String name = txtname.getText();
        String fname = txtfname.getText();
        String gender = txtgender.getText();
        String dob = txtdob.getText();
        String vote = txtvote.getText().toUpperCase();

        try {
            pst = con.prepareStatement("SELECT nic from votesection where nic = ?");
            pst.setString(1, nic);
            final ResultSet rs = pst.executeQuery();
            if (txtnic.getText().equals("")) {
                JOptionPane.showMessageDialog(this, "CNIC field cannot be blank");
            } else if (rs.next() == true) {
                JOptionPane.showMessageDialog(rootPane, "You have already cast your vote. Thank you for participating.", "error", HEIGHT);
                MainSection obj = new MainSection();
                this.hide();
                obj.setVisible(true);
            } else {
                try {
                    pst = con.prepareStatement("insert into votesection(nic,name,fname,gender,dob,vote)values(?,?,?,?,?,?)");
                    pst.setString(1, nic);
                    pst.setString(2, name);
                    pst.setString(3, fname);
                    pst.setString(4, gender);
                    pst.setString(5, dob);
                    pst.setString(6, vote);

                    pst.executeUpdate();
                    tableUpdate();
                    JOptionPane.showMessageDialog(null, "Your vote has been cast. Thank you for participating.");
                    MainSection obj = new MainSection();

                    this.hide();
                    obj.setVisible(true);

                    txtnic.setText("");
                    txtname.setText("");
                    txtfname.setText("");
                    txtgender.setText("");
                    txtdob.setText("");
                    txtvote.setText("");
                    txtnic.requestFocus();

                } catch (SQLException ex) {
                    Logger.getLogger(VoteSection.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(VoteSection.class.getName()).log(Level.SEVERE, null, ex);
        }
//        Threads
        new Thread(new Runnable() {
            @Override
            public void run() {
                voteCounter.countVotes();
            }

        });
        Thread t1 = new Thread();
        t1.start();
    }

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        MainSection obj = new MainSection();
        this.hide();
        obj.setVisible(true);
    }//GEN-LAST:event_backButtonActionPerformed

    private void txtnicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnicActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnicActionPerformed

    private void txtnicKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnicKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            String nic = txtnic.getText();
            try {
                pst = con.prepareStatement("SELECT a.name,a.fname,a.gender,a.dob FROM adminpanel a where a.nic = ?");

                pst.setString(1, nic);
                ResultSet rs = pst.executeQuery();
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(this, "You have not been registered. Please contact the administrator for assistance.");
                    txtnic.setText("");
                } else {
                    String name = rs.getString("a.name");
                    String fname = rs.getString("a.fname");
                    String gender = rs.getString("a.gender");
                    String dob = rs.getString("a.dob");

                    txtname.setText(name.trim());
                    txtfname.setText(fname.trim());
                    txtgender.setText(gender.trim());
                    txtdob.setText(dob.trim());
                }
            } catch (SQLException ex) {
                Logger.getLogger(VoteSection.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_txtnicKeyPressed

    private void JiVoteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JiVoteButtonActionPerformed
        if (txtnic.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please Enter your Cnic number", "Error", HEIGHT);
        } else if (txtname.getText().equals("") && txtfname.getText().equals("") && txtgender.getText().equals("") && txtdob.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Press Enter first to check details", "Error", HEIGHT);
        } else {
            txtvote.setText("ji");
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to cast vote to JI?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
//            Calling votingMethod
                votingMethod();
            } else if (option == JOptionPane.NO_OPTION) {
                txtvote.setText("");
            }
        }
    }//GEN-LAST:event_JiVoteButtonActionPerformed

    private void mqmVoteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mqmVoteButtonActionPerformed
        if (txtnic.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please enter your CNIC number", "Error", HEIGHT);
        } else if (txtname.getText().equals("") && txtfname.getText().equals("") && txtgender.getText().equals("") && txtdob.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Press Enter first to check details", "Error", HEIGHT);
        } else {
            txtvote.setText("mqm");
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to cast vote to MQM?", "Confirm", JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {
                votingMethod();
            } else if (option == JOptionPane.NO_OPTION) {
                txtvote.setText("");
            }
        }
    }//GEN-LAST:event_mqmVoteButtonActionPerformed

    private void ptiVoteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ptiVoteButtonActionPerformed
        if (txtnic.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please enter your CNIC number", "Error", HEIGHT);
        } else if (txtname.getText().equals("") && txtfname.getText().equals("") && txtgender.getText().equals("") && txtdob.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Press Enter first to check details", "Error", HEIGHT);
        } else {
            txtvote.setText("pti");
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to cast vote to PTI?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                //do something
                votingMethod();
            } else if (option == JOptionPane.NO_OPTION) {
                //do something else
                txtvote.setText("");
            }
        }
    }//GEN-LAST:event_ptiVoteButtonActionPerformed

    private void pppVoteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pppVoteButtonActionPerformed
        // TODO add your handling code here:
        if (txtnic.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please enter your CNIC number", "Error", HEIGHT);
        } else if (txtname.getText().equals("") && txtfname.getText().equals("") && txtgender.getText().equals("") && txtdob.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Press Enter first to check details", "Error", HEIGHT);
        } else {
            txtvote.setText("ppp");
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to cast vote to PPP?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                //Calling votingMethod
                votingMethod();
            } else if (option == JOptionPane.NO_OPTION) {
                txtvote.setText("");
            }
        }
    }//GEN-LAST:event_pppVoteButtonActionPerformed

    private void pmlnVoteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pmlnVoteButtonActionPerformed
        if (txtnic.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Please enter your CNIC number", "Error", HEIGHT);
        } else if (txtname.getText().equals("") && txtfname.getText().equals("") && txtgender.getText().equals("") && txtdob.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "Press Enter first to check details", "Error", HEIGHT);
        } else {
            txtvote.setText("pmln");
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to cast vote to PMLN?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                votingMethod();
            } else if (option == JOptionPane.NO_OPTION) {
                txtvote.setText("");
            }
        }
    }//GEN-LAST:event_pmlnVoteButtonActionPerformed

    private void txtvoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtvoteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtvoteActionPerformed

    private void ptiVoteButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ptiVoteButtonMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_ptiVoteButtonMouseEntered

    private void PartiesButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PartiesButton2ActionPerformed
        // TODO add your handling code here:
        PartiesSection obj = new PartiesSection();
        this.hide();
        obj.setVisible(true);
    }//GEN-LAST:event_PartiesButton2ActionPerformed

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VoteSection().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private final javax.swing.JButton JiVoteButton = new javax.swing.JButton();
    private javax.swing.JButton PartiesButton2;
    private javax.swing.JButton backButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private final javax.swing.JButton mqmVoteButton = new javax.swing.JButton();
    private final javax.swing.JButton pmlnVoteButton = new javax.swing.JButton();
    private final javax.swing.JButton pppVoteButton = new javax.swing.JButton();
    private final javax.swing.JButton ptiVoteButton = new javax.swing.JButton();
    private javax.swing.JLabel txtdob;
    private javax.swing.JLabel txtfname;
    private javax.swing.JLabel txtgender;
    private javax.swing.JLabel txtname;
    private final javax.swing.JTextField txtnic = new javax.swing.JTextField();
    private javax.swing.JTextField txtvote;
    // End of variables declaration//GEN-END:variables
}
