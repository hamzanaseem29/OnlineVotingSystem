package VotingSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public final class AdminPanel extends javax.swing.JFrame {

    public AdminPanel() {
        initComponents();
        Connect();
        tableUpdate();
    }
    Connection con;
    PreparedStatement pst;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        NameTextField = new javax.swing.JTextField();
        NicTextField = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        backButton1 = new javax.swing.JButton();
        ResultButton = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        dobTextField = new javax.swing.JTextField();
        FatherNameTextField = new javax.swing.JTextField();
        GenderTextField = new javax.swing.JTextField();
        UpdateButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Panel");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setFont(new java.awt.Font("Montserrat Light", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "NIC", "Name", "Father Name", "Gender", "Date of Birth"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 100, 520, 390));

        jLabel2.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        jLabel2.setText("NIC");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, -1, -1));

        jLabel4.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        jLabel4.setText("Gender");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, -1, -1));

        jLabel5.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        jLabel5.setText("Name");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, -1));
        jPanel1.add(NameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 210, 30));

        NicTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NicTextFieldActionPerformed(evt);
            }
        });
        jPanel1.add(NicTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 210, 30));

        jPanel2.setBackground(new java.awt.Color(102, 102, 255));

        jLabel7.setFont(new java.awt.Font("Montserrat ExtraBold", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Admin Panel");

        backButton1.setBackground(new java.awt.Color(204, 204, 255));
        backButton1.setFont(new java.awt.Font("Montserrat Medium", 0, 18)); // NOI18N
        backButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/left-arrow.png"))); // NOI18N
        backButton1.setText(" Back");
        backButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButton1ActionPerformed(evt);
            }
        });

        ResultButton.setBackground(new java.awt.Color(204, 204, 255));
        ResultButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        ResultButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/pngwing.com (4) (Custom).png"))); // NOI18N
        ResultButton.setText("Results");
        ResultButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResultButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(ResultButton, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 141, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(180, 180, 180)
                .addComponent(backButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(backButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ResultButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 910, 80));

        jButton2.setBackground(new java.awt.Color(102, 102, 255));
        jButton2.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Add");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jButton2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButton2KeyPressed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 410, 130, 40));

        jLabel6.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        jLabel6.setText("Father Name");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, -1));
        jPanel1.add(dobTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 310, 210, 30));
        jPanel1.add(FatherNameTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, 210, 30));
        jPanel1.add(GenderTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 270, 210, 30));

        UpdateButton.setBackground(new java.awt.Color(102, 102, 255));
        UpdateButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        UpdateButton.setForeground(new java.awt.Color(255, 255, 255));
        UpdateButton.setText("Update");
        UpdateButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UpdateButtonMouseClicked(evt);
            }
        });
        UpdateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateButtonActionPerformed(evt);
            }
        });
        UpdateButton.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                UpdateButtonKeyPressed(evt);
            }
        });
        jPanel1.add(UpdateButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 410, 130, 40));

        jLabel3.setFont(new java.awt.Font("Montserrat SemiBold", 0, 14)); // NOI18N
        jLabel3.setText("DOB");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 908, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 519, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
      public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinevotingsys", "root", "");
            } catch (SQLException ex) {
                Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    private void tableUpdate() {

        int c;
        try {

            pst = con.prepareStatement("select * from  adminpanel");
            ResultSet rs = pst.executeQuery();

            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();

            DefaultTableModel d = (DefaultTableModel) jTable1.getModel();
            d.setRowCount(0);

            while (rs.next()) {
                Vector v2 = new Vector();

                for (int i = 1; i <= c; i++) {
                    v2.add(rs.getString("nic"));
                    v2.add(rs.getString("name"));
                    v2.add(rs.getString("fname"));
                    v2.add(rs.getString("gender"));
                    v2.add(rs.getString("dob"));
                }
                d.addRow(v2);

            }

        } catch (SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    // setter methods

    public void setNic(String nic) {
        this.NicTextField.setText(nic);
    }

    public void setName(String name) {
        this.NameTextField.setText(name);
    }

    public void setFatherName(String fname) {
        this.FatherNameTextField.setText(fname);
    }

    public void setGender(String gender) {
        this.GenderTextField.setText(gender);
    }

    public void setDOB(String dob) {
        this.dobTextField.setText(dob);
    }

//    Update button action
    public void updateData() throws ArrayIndexOutOfBoundsException {
        DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
        int selectIndex = jTable1.getSelectedRow();

        int id = Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
        String nic = NicTextField.getText();
        String name = NameTextField.getText();
        String fname = FatherNameTextField.getText();
        String gender = GenderTextField.getText();
        String dob = dobTextField.getText();
        if (selectIndex == -1) {
            throw new ArrayIndexOutOfBoundsException("Index out of bounds ");
        } else if (NicTextField.getText().equals("") || NameTextField.getText().equals("") || FatherNameTextField.getText().equals("") || GenderTextField.getText().equals("") || dobTextField.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "All fields are required");
        } else {
            try {
                pst = con.prepareStatement("update adminpanel set nic=?,name=?,fname=?,gender=?,dob=? where nic= ?");
                pst.setString(1, nic);
                pst.setString(2, name);
                pst.setString(3, fname);
                pst.setString(4, gender);
                pst.setString(5, dob);
                pst.setInt(6, id);

                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "Person data updated successfully");
                tableUpdate();
                // call setter methods to update the values
                setNic(nic);
                setName(name);
                setFatherName(fname);
                setGender(gender);
                setDOB(dob);
                NicTextField.requestFocus();

                NicTextField.setText("");
                NameTextField.setText("");
                FatherNameTextField.setText("");
                GenderTextField.setText("");
                dobTextField.setText("");
                NicTextField.requestFocus();

            } catch (SQLException ex) {
                Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void NicTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NicTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NicTextFieldActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        String nic = NicTextField.getText();
        String name = NameTextField.getText();
        String Fathername = FatherNameTextField.getText();
        String gender = GenderTextField.getText();
        String dob = dobTextField.getText();

        if (NicTextField.getText().equals("") || NameTextField.getText().equals("") || FatherNameTextField.getText().equals("") || GenderTextField.getText().equals("") || dobTextField.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "All fields are required");
        } else {

            try {
                pst = con.prepareStatement("SELECT nic from adminpanel where nic = ?");

                pst.setString(1, nic);
                ResultSet rs = pst.executeQuery();
                if (rs.next() == true) {
                    JOptionPane.showMessageDialog(this, "CNIC number cannot be the same as someone else's");
                    NicTextField.setText("");
                } else {
                    try {
                        pst = con.prepareStatement("insert into adminpanel(nic,name,fname,gender,dob)values(?,?,?,?,?)");
                        pst.setString(1, nic);
                        pst.setString(2, name);
                        pst.setString(3, Fathername);
                        pst.setString(4, gender);
                        pst.setString(5, dob);
                        pst.executeUpdate();
                        JOptionPane.showMessageDialog(this, "Person has been added successfully");
                        tableUpdate();

                        NicTextField.setText("");
                        NameTextField.setText("");
                        FatherNameTextField.setText("");
                        GenderTextField.setText("");
                        dobTextField.setText("");
                        NicTextField.requestFocus();
                    } catch (SQLException ex) {
                        Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            } catch (SQLException ex) {
                Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }


    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton2KeyPressed

    }//GEN-LAST:event_jButton2KeyPressed

    private void UpdateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateButtonActionPerformed
        // TODO add your handling code here:
        updateData();
    }//GEN-LAST:event_UpdateButtonActionPerformed

    private void UpdateButtonKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_UpdateButtonKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_UpdateButtonKeyPressed

    private void backButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButton1ActionPerformed
        MainSection obj = new MainSection();
        this.hide();
        obj.setVisible(true);
    }//GEN-LAST:event_backButton1ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
        int selectIndex = jTable1.getSelectedRow();

        NicTextField.setText(d1.getValueAt(selectIndex, 0).toString());
        NameTextField.setText(d1.getValueAt(selectIndex, 1).toString());
        FatherNameTextField.setText(d1.getValueAt(selectIndex, 2).toString());
        GenderTextField.setText(d1.getValueAt(selectIndex, 3).toString());
        dobTextField.setText(d1.getValueAt(selectIndex, 4).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void ResultButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResultButtonActionPerformed
        // TODO add your handling code here:
        ResultSection obj = new ResultSection();
        this.hide();
        obj.setVisible(true);
    }//GEN-LAST:event_ResultButtonActionPerformed

    private void UpdateButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UpdateButtonMouseClicked
        // TODO add your handling code here:
        try {
            int selectIndex = jTable1.getSelectedRow();
            if (selectIndex == -1) {
                JOptionPane.showMessageDialog(null, "Please select a row to update.", "Error", JOptionPane.ERROR_MESSAGE);
                throw new ArrayIndexOutOfBoundsException();
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Index is out of range!");
        }
    }//GEN-LAST:event_UpdateButtonMouseClicked

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AdminPanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField FatherNameTextField;
    private javax.swing.JTextField GenderTextField;
    private javax.swing.JTextField NameTextField;
    private javax.swing.JTextField NicTextField;
    private javax.swing.JButton ResultButton;
    private javax.swing.JButton UpdateButton;
    private javax.swing.JButton backButton1;
    private javax.swing.JTextField dobTextField;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
