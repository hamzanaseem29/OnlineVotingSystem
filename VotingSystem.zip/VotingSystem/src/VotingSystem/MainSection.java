
package VotingSystem;

import static java.lang.System.exit;

/**
 *
 * @author USER
 */
public class MainSection extends javax.swing.JFrame {

    public MainSection() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        VoteButton = new javax.swing.JButton();
        LogoutButton = new javax.swing.JButton();
        ResultButton = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        AdminButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        PartiesButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setTitle("Online Voting System");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        VoteButton.setBackground(new java.awt.Color(102, 102, 255));
        VoteButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        VoteButton.setForeground(new java.awt.Color(255, 255, 255));
        VoteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/votedoneimg (Custom).png"))); // NOI18N
        VoteButton.setText("Vote");
        VoteButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        VoteButton.setDisabledIcon(new javax.swing.ImageIcon("C:\\Users\\USER\\Desktop\\SSUET_Logo.png")); // NOI18N
        VoteButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                VoteButtonMouseEntered(evt);
            }
        });
        VoteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoteButtonActionPerformed(evt);
            }
        });
        jPanel1.add(VoteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 170, 60));

        LogoutButton.setBackground(new java.awt.Color(102, 102, 255));
        LogoutButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        LogoutButton.setForeground(new java.awt.Color(255, 255, 255));
        LogoutButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/pngwing.com (1) (Custom) (1).png"))); // NOI18N
        LogoutButton.setText("Exit");
        LogoutButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogoutButtonMouseClicked(evt);
            }
        });
        LogoutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutButtonActionPerformed(evt);
            }
        });
        jPanel1.add(LogoutButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 380, 170, 60));

        ResultButton.setBackground(new java.awt.Color(102, 102, 255));
        ResultButton.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        ResultButton.setForeground(new java.awt.Color(255, 255, 255));
        ResultButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/pngwing.com (4) (Custom).png"))); // NOI18N
        ResultButton.setText("Results");
        ResultButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResultButtonActionPerformed(evt);
            }
        });
        jPanel1.add(ResultButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 380, 170, 60));

        jPanel2.setBackground(new java.awt.Color(102, 102, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Montserrat Black", 1, 40)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Online Voting System");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, -1, 60));

        AdminButton.setBackground(new java.awt.Color(153, 153, 255));
        AdminButton.setFont(new java.awt.Font("Montserrat Medium", 1, 18)); // NOI18N
        AdminButton.setForeground(new java.awt.Color(255, 255, 255));
        AdminButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/permission (2).png"))); // NOI18N
        AdminButton.setText("  Admin");
        AdminButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminButtonActionPerformed(evt);
            }
        });
        jPanel2.add(AdminButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 22, 150, 50));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 90));

        jLabel3.setText("jLabel3");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 400, -1, -1));

        jLabel5.setText("jLabel5");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 400, -1, -1));

        PartiesButton2.setBackground(new java.awt.Color(102, 102, 255));
        PartiesButton2.setFont(new java.awt.Font("Montserrat SemiBold", 0, 18)); // NOI18N
        PartiesButton2.setForeground(new java.awt.Color(255, 255, 255));
        PartiesButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/pngwing.com (6) (Custom) (1).png"))); // NOI18N
        PartiesButton2.setText("Parties");
        PartiesButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PartiesButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(PartiesButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 380, 170, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/onlinevotingimages/COVERMAIN.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 730, 330));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 490, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void AdminButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminButtonActionPerformed
        // TODO add your handling code here:
        AdminLoginPage obj = new AdminLoginPage();
        obj.setVisible(true);
        this.hide();
    }//GEN-LAST:event_AdminButtonActionPerformed

    private void LogoutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutButtonActionPerformed
        // TODO add your handli
    }//GEN-LAST:event_LogoutButtonActionPerformed

    private void ResultButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResultButtonActionPerformed
        // TODO add your handling code here:
        ResultSection obj = new ResultSection();
        this.hide();
        obj.setVisible(true);
    }//GEN-LAST:event_ResultButtonActionPerformed

    private void VoteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoteButtonActionPerformed
        // TODO add your handling code here:
        VoteSection obj = new VoteSection();
        this.hide();
        obj.setVisible(true);
    }//GEN-LAST:event_VoteButtonActionPerformed

    private void LogoutButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LogoutButtonMouseClicked
        // TODO add your handling code here:
        exit(0);
    }//GEN-LAST:event_LogoutButtonMouseClicked

    private void PartiesButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PartiesButton2ActionPerformed
        // TODO add your handling code here:
        PartiesSection obj = new PartiesSection();
        this.hide();
        obj.setVisible(true);

    }//GEN-LAST:event_PartiesButton2ActionPerformed

    private void VoteButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VoteButtonMouseEntered


    }//GEN-LAST:event_VoteButtonMouseEntered

   
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminLoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(() -> {
            new MainSection().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AdminButton;
    private javax.swing.JButton LogoutButton;
    private javax.swing.JButton PartiesButton2;
    private javax.swing.JButton ResultButton;
    private javax.swing.JButton VoteButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
