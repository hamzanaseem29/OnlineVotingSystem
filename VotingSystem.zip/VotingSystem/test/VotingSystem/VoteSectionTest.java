/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package VotingSystem;

import com.sun.jdi.connect.spi.Connection;
import static java.awt.image.ImageObserver.HEIGHT;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author USER
 */
public class VoteSectionTest {

    java.sql.Connection con;
    PreparedStatement pst;

    public VoteSectionTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @Test
    public void testConnect() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (java.sql.Connection) (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinevotingsys", "root", "");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(VoteSection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Test
    public void testTableUpdate() {
        int c;
        try {
            pst = con.prepareStatement("select * from  votesection");
            ResultSet rs = pst.executeQuery();

            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();
            while (rs.next()) {
                Vector v2 = new Vector();

                for (int i = 1; i <= c; i++) {

                    v2.add(rs.getString("nic"));
                    v2.add(rs.getString("name"));
                    v2.add(rs.getString("fname"));
                    v2.add(rs.getString("gender"));
                    v2.add(rs.getString("dob"));
                    v2.add(rs.getString("vote"));

                }
               
            }
        } catch (SQLException ex) {
            Logger.getLogger(VoteSection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Test
    public void testVotingMethod() {
     String  nic = "2222";
     String txtnic = nic;

        try {
            pst = con.prepareStatement("SELECT nic from votesection where nic = ?");
            pst.setString(1, nic);
            final ResultSet rs = pst.executeQuery();
            if (txtnic.equals("")) {
                JOptionPane.showMessageDialog(null, "CNIC field cannot be blank");
            } else if (rs.next() == true) {
                JOptionPane.showMessageDialog(null, "You have already cast your vote. Thank you for participating.", "error", HEIGHT);
                MainSection obj = new MainSection();
               
                obj.setVisible(true);
            } else {
                try {
                    pst = con.prepareStatement("insert into votesection(nic,name,fname,gender,dob,vote)values(?,?,?,?,?,?)");
                    pst.setString(1, nic);
                   pst.executeUpdate();
                    
                    JOptionPane.showMessageDialog(null, "Your vote has been cast. Thank you for participating.");
                    MainSection obj = new MainSection();

                   
                    obj.setVisible(true);

               

                } catch (SQLException ex) {
                    Logger.getLogger(VoteSection.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(VoteSection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Test
    public void testMain() {
         java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VoteSection().setVisible(true);

            }
        });
    }

}
